<!DOCTYPE html>
<html>

<?php
include('session_customer.php');

if (!isset($_SESSION['login_customer'])) {
    session_destroy();
    header("location: customerlogin.php");
}
?>

<title>Reserveer auto</title>

<head>
    <script type="text/javascript" src="assets/ajs/angular.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="shortcut icon" type="image/png" href="assets/img/P.png.png">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/w3css/w3.css">
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/custom.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="assets/css/clientpage.css" />
</head>

<body ng-app="">

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation" style="color: black">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="index.php">auto verhuur </a>
            </div>

            <?php
            if (isset($_SESSION['login_client'])) {
            ?>
                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <a href="#"><span class="glyphicon glyphicon-user"></span> Welkom <?php echo $_SESSION['login_client']; ?></a>
                        </li>
                        <li>
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span> Control Panel <span class="caret"></span> </a>
                                    <ul class="dropdown-menu">
                                        <li> <a href="entercar.php">voertuig toevoegen</a></li>
                                        <li> <a href="enterdriver.php"> Bestuurder toevoegen</a></li>
                                        <li> <a href="clientview.php">Bekijk</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Uitloggen</a>
                        </li>
                    </ul>
                </div>

            <?php
            } else if (isset($_SESSION['login_customer'])) {
            ?>
                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <a href="#"><span class="glyphicon glyphicon-user"></span> Welkom <?php echo $_SESSION['login_customer']; ?></a>
                        </li>
                        <ul class="nav navbar-nav">
                            <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Garagge <span class="caret"></span> </a>
                                <ul class="dropdown-menu">
                                    <li> <a href="prereturncar.php">Terugkeren</a></li>
                                    <li> <a href="mybookings.php"> mijn reserveringen</a></li>
                                </ul>
                            </li>
                        </ul>
                        <li>
                            <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Uitloggen</a>
                        </li>
                    </ul>
                </div>

            <?php
            } else {
            ?>

                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <a href="clientlogin.php">Admin</a>
                        </li>
                        <li>
                            <a href="customerlogin.php">Klant</a>
                        </li>
                    </ul>
                </div>
            <?php   }
            ?>
        </div>
    </nav>

    <div class="container" style="margin-top: 65px;">
        <div class="col-md-7" style="float: none; margin: 0 auto;">
            <div class="form-area">
                <form role="form" action="bookingconfirm.php" method="POST">
                    <br style="clear: both">
                    <br>

                    <?php
                    $car_id = $_GET["id"];
                    try {
                        $sql1 = "SELECT * FROM cars WHERE car_id = :car_id";
                        $stmt1 = $conn->prepare($sql1);
                        $stmt1->bindParam(':car_id', $car_id);
                        $stmt1->execute();

                        $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);

                        if ($row1) {
                            $car_name = $row1["car_name"];
                            $car_nameplate = $row1["car_nameplate"];
                            $ac_price = $row1["ac_price"];
                            $non_ac_price = $row1["non_ac_price"];
                            $ac_price_per_day = $row1["ac_price_per_day"];
                            $non_ac_price_per_day = $row1["non_ac_price_per_day"];
                        }
                    } catch (PDOException $e) {
                        echo "Error: " . $e->getMessage();
                    }
                    ?>

                    <h5> Geselecteerde voertuig:&nbsp; <b><?php echo $car_name; ?></b></h5>
                    <h5> Kenteken:&nbsp;<b> <?php echo $car_nameplate; ?></b></h5>

                    <label><h5>Start datum:</h5></label>
                    <input type="date" name="rent_start_date" min="<?php echo date("Y-m-d"); ?>" required="">
                    &nbsp;
                    <label><h5>Eind datum:</h5></label>
                    <input type="date" name="rent_end_date" min="<?php echo date("Y-m-d"); ?>" required="">

                    <h5> Kies uw auto type: &nbsp;
                        <input onclick="reveal()" type="radio" name="radio" value="ac" ng-model="myVar"> <b>With AC </b>&nbsp;
                        <input onclick="reveal()"
                        <input onclick="reveal()" type="radio" name="radio" value="non_ac" ng-model="myVar"><b>With-Out AC </b>
                    </h5>

                    <div ng-switch="myVar">
                        <div ng-switch-default>
                            <h5>Fare: <h5>
                        </div>
                        <div ng-switch-when="ac">
                            <h5>Fare: <b><?php echo "€. " . $ac_price . "/km and €. " . $ac_price_per_day . "/day"; ?></b><h5>
                        </div>
                        <div ng-switch-when="non_ac">
                            <h5>Fare: <b><?php echo "€. " . $non_ac_price . "/km and €. " . $non_ac_price_per_day . "/day"; ?></b><h5>
                        </div>
                    </div>

                    <h5> type kosten: &nbsp;
                        <input onclick="reveal()" type="radio" name="radio1" value="km"><b> per KM</b> &nbsp;
                        <input onclick="reveal()" type="radio" name="radio1" value="days"><b> per dag</b>
                    </h5>

                    <br><br>
                    Selecteer eventueel bestuurder: &nbsp;
                    <select name="driver_id_from_dropdown" ng-model="myVar1">
                        <?php
                        $sql2 = "SELECT * FROM driver d WHERE d.driver_availability = 'yes' AND d.client_username IN (SELECT cc.client_username FROM clientcars cc WHERE cc.car_id = :car_id)";
                        $stmt2 = $conn->prepare($sql2);
                        $stmt2->bindParam(':car_id', $car_id);
                        $stmt2->execute();

                        if ($stmt2->rowCount() > 0) {
                            while ($row2 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                                $driver_id = $row2["driver_id"];
                                $driver_name = $row2["driver_name"];
                                $driver_gender = $row2["driver_gender"];
                                $driver_phone = $row2["driver_phone"];
                        ?>
                                <option value="<?php echo $driver_id; ?>"><?php echo $driver_name; ?></option>
                        <?php
                            }
                        } else {
                        ?>
                            <option disabled>Helaas zijn er geen bestuurders beschikbaar</option>
                        <?php
                        }
                        ?>
                    </select>

                    <div ng-switch="myVar1">
                        <?php
                        $sql3 = "SELECT * FROM driver d WHERE d.driver_availability = 'yes' AND d.client_username IN (SELECT cc.client_username FROM clientcars cc WHERE cc.car_id = :car_id)";
                        $stmt3 = $conn->prepare($sql3);
                        $stmt3->bindParam(':car_id', $car_id);
                        $stmt3->execute();

                        if ($stmt3->rowCount() > 0) {
                            while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)) {
                                $driver_id = $row3["driver_id"];
                                $driver_name = $row3["driver_name"];
                                $driver_gender = $row3["driver_gender"];
                                $driver_phone = $row3["driver_phone"];
                        ?>
                                <div ng-switch-when="<?php echo $driver_id; ?>">
                                    <h5>Bestuurder naam:&nbsp; <b><?php echo $driver_name; ?></b></h5>
                                    <p>Geslacht:&nbsp; <b><?php echo $driver_gender; ?></b> </p>
                                    <p>Contact:&nbsp; <b><?php echo $driver_phone; ?></b> </p>
                                </div>
                        <?php
                            }
                        }
                        ?>
                    </div>

                    <input type="hidden" name="hidden_carid" value="<?php echo $car_id; ?>">

                    <input type="submit" name="submit" value="Huur nu" class="btn btn-warning pull-right">
                </form>

            </div>
            <div class="col-md-12" style="float: none; margin: 0 auto; text-align: center;">
                <h6><strong>Let op:</strong> Er wordt 5€ extra in rekening gebracht voor elke dag extra.</h6>
            </div>
        </div>

    </div>

    </body>
    <footer class="site-footer">
        <div 
