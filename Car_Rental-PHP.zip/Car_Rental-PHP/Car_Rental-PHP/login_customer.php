<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$error = '';

if (isset($_POST['submit'])) {
    if (empty($_POST['customer_username']) || empty($_POST['customer_password'])) {
        $error = "Gebruikersnaam of wachtwoord is ongeldig";
    } else {
        // Definieer $username en $password
        $customer_username = $_POST['customer_username'];
        $customer_password = $_POST['customer_password'];

        // Verbinding maken met de server met behulp van PDO
        require 'connection.php';

        // Controleer of de verbinding succesvol is
        if (!$database->connected) {
            die("Verbinding mislukt: " . $database->getConnectionError());
        }

        // SQL-query om informatie van geregistreerde gebruikers op te halen en een gebruikersmatch te vinden.
        $query = "SELECT customer_username, customer_password FROM customers WHERE customer_username=:customer_username AND customer_password=:customer_password LIMIT 1";

        try {
            // Ter bescherming tegen SQL-injectie, gebruik prepared statements
            $stmt = $database->conn->prepare($query);
            $stmt->bindParam(':customer_username', $customer_username);
            $stmt->bindParam(':customer_password', $customer_password);
            $stmt->execute();

            if ($stmt->fetch()) {
                $_SESSION['login_customer'] = $customer_username;
                header("location: index.php");
            } else {
                $error = "Gebruikersnaam of wachtwoord is ongeldig";
            }
        } catch (PDOException $e) {
            echo "Query mislukt: " . $e->getMessage();
        } finally {
            // Sluit de verbinding
            $database->closeConnection();
        }
    }
}
?>
