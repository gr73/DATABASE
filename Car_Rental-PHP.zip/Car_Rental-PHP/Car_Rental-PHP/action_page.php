<!DOCTYPE html>
<html>
<?php 
session_start(); 
require 'connection.php';
$conn = Connect();
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Rentals</title>
    <link rel="shortcut icon" type="image/png" href="assets/img/P.png.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/w3css/w3.css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700,400italic,700italic" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
</head>

<body>
    <?php 
    $name = $_POST['name'];
    $e_mail = $_POST['e_mail'];
    $message = $_POST['message'];

    try {
        $conn->beginTransaction();

        $sql = "INSERT INTO feedback (name, e_mail, message) VALUES (:name, :e_mail, :message)";
        $stmt = $conn->prepare($sql);

        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':e_mail', $e_mail);
        $stmt->bindParam(':message', $message);

        $stmt->execute();

        $conn->commit();
        ?>
        <div class="container">
            <div class="jumbotron" style="text-align: center;">
                Bedankt voor uw bericht!    
                <br><br>
                <a href="index.php" class="btn btn-default"> Ga terug </a>
            </div>
        </div>
        <?php
    } catch (PDOException $e) {
        $conn->rollBack();
        echo "Error: " . $e->getMessage();
    }
    ?>
</body>
<footer class="site-footer">
    <div class="container">
        <hr>
        <div class="row">
            <div class="col-sm-6">
                <h5> <?php echo date("Y"); ?> auto verhuur</h5>
            </div>
        </div>
    </div>
</footer>
</html>
