<!DOCTYPE html>
<html>
<?php
session_start();
require 'connection.php';

try {
    $conn = new PDO("mysql:host=localhost:3307;dbname=carrentalp", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
<head>
    <link rel="shortcut icon" type="image/png" href="assets/img/P.png.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/w3css/w3.css">
    <link rel="stylesheet" type="text/css" href="assets/css/customerlogin.css">
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="assets/css/clientpage.css" />
</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
    <!-- Navigation -->
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation" style="color: black">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="index.php">Auto verhuur </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <?php
            if (isset($_SESSION['login_client'])) {
            ?>
                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Welkom<?php echo $_SESSION['login_client']; ?></a></li>
                        <li>
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span> Control Panel <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="entercar.php">Voertuig toevoegen</a></li>
                                        <li><a href="clientview.php">Bekijk Reserveringen</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Uitloggen</a></li>
                    </ul>
                </div>
            <?php
            } elseif (isset($_SESSION['login_customer'])) {
            ?>
                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Welkom <?php echo $_SESSION['login_customer']; ?></a></li>
                        <ul class="nav navbar-nav">
                            <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Garage <span class="caret"></span> </a>
                                <ul class="dropdown-menu">
                                    <li><a href="prereturncar.php">Terugbrengen</a></li>
                                    <li><a href="mybookings.php"> Mijn reserveringen</a></li>
                                </ul>
                            </li>
                        </ul>
                        <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Uitloggen</a></li>
                    </ul>
                </div>
            <?php
            } else {
            ?>
                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="clientlogin.php">Admin</a></li>
                        <li><a href="customerlogin.php">Klant</a></li>
                    </ul>
                </div>
            <?php
            }
            ?>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Body van de pagina -->
    <?php
    $login_client = $_SESSION['login_client'];

    $sql1 = "SELECT * FROM rentedcars rc
             INNER JOIN clientcars cc ON cc.car_id = rc.car_id
             INNER JOIN customers c ON c.customer_username = rc.customer_username
             INNER JOIN cars ON cc.car_id = cars.car_id
             WHERE cc.client_username = :login_client AND rc.return_status = 'R'";

    $stmt1 = $conn->prepare($sql1);
    $stmt1->bindParam(':login_client', $login_client);
    $stmt1->execute();

    $result1 = $stmt1->fetchAll(PDO::FETCH_ASSOC);

    if ($stmt1->rowCount() > 0) {
    ?>
        <div class="container">
            <div class="jumbotron">
                <h1 class="text-center">Alle reserveringen</h1>
            </div>
        </div>

        <div class="table-responsive" style="padding-left: 100px; padding-right: 100px;">
            <table class="table table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th width="20%">Voertuig</th>
                        <th width="15%">Klant naam</th>
                        <th width="20%">Verhuur start datum</th>
                        <                        <th width="20%">Eind datum verhuur</th>
                        <th width="10%">Afstand</th>
                        <th width="15%">Totaal bedrag</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($result1 as $row) {
                    ?>
                        <tr>
                            <td><?php echo $row["car_name"]; ?></td>
                            <td><?php echo $row["customer_name"]; ?></td>
                            <td><?php echo $row["rent_start_date"] ?></td>
                            <td><?php echo $row["rent_end_date"]; ?></td>
                            <td><?php echo $row["distance"]; ?></td>
                            <td>€. <?php echo $row["total_amount"]; ?></td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    <?php
    } else {
    ?>
        <div class="container">
            <div class="jumbotron">
                <h1>Geen boekingen</h1>
                <p> <?php echo $conn->error; ?> </p>
            </div>
        </div>
    <?php
    }
    ?>

    </body>
    <footer class="site-footer">
        <div class="container">
            <hr>
            <div class="row">
                <div class="col-sm-6">
                    <h5> <?php echo date("Y"); ?> Auto verhuur</h5>
                </div>
            </div>
        </div>
    </footer>
</html>

