<?php
session_start();
$error = '';

if (isset($_POST['submit'])) {
    if (empty($_POST['client_username']) || empty($_POST['client_password'])) {
        $error = "Gebruikersnaam of wachtwoord is ongeldig";
    } else {
        require 'connection.php';

        try {
            $database = new Database(); // Gebruik hier de daadwerkelijke naam van je databaseklasse
            $database->connect();

            $client_username = $_POST['client_username'];
            $client_password = $_POST['client_password'];

            $query = "SELECT client_username, client_password FROM clients WHERE client_username=:client_username AND client_password=:client_password LIMIT 1";

            $stmt = $database->conn->prepare($query);
            $stmt->bindParam(':client_username', $client_username);
            $stmt->bindParam(':client_password', $client_password);
            $stmt->execute();

            if ($stmt->fetch()) {
                $_SESSION['login_client'] = $client_username;
                header("location: index.php");
            } else {
                $error = "Gebruikersnaam of wachtwoord is ongeldig";
            }
        } catch (PDOException $e) {
            echo "Query mislukt: " . $e->getMessage();
        } finally {
            if (isset($database)) {
                $database->closeConnection();
            }
        }
    }
}
?>
