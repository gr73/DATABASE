<?php
require 'connection.php';

$conn = new Database();
$conn->connect();

session_start();

$user_check = $_SESSION['login_customer'];

$sql = "SELECT customer_username FROM customers WHERE customer_username = :user_check";
$stmt = $conn->getPDO()->prepare($sql); // Use getPDO method to get the PDO instance
$stmt->bindParam(':user_check', $user_check);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

$login_session = $row['customer_username'];
?>
