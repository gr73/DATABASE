<?php
require 'connection.php';

// Maak een instantie van de Database-klasse
$database = new Database();
// Verbinding maken met de database
$database->connect();

session_start();

$user_check = $_SESSION['login_client'];

// SQL-query om volledige informatie van de gebruiker op te halen
$sql = "SELECT client_username FROM clients WHERE client_username = :user_check";
$stmt = $database->prepare($sql);
$stmt->bindParam(':user_check', $user_check);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

$login_session = $row['client_username'];
?>
