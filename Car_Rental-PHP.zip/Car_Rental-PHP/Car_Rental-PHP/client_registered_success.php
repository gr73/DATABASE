<?php
require 'connection.php';
$conn = Connect();

session_start();

$client_name = $_POST['client_name'];
$client_username = $_POST['client_username'];
$client_email = $_POST['client_email'];
$client_phone = $_POST['client_phone'];
$client_address = $_POST['client_address'];
$client_password = $_POST['client_password'];

$query = "INSERT INTO clients (client_name, client_username, client_email, client_phone, client_address, client_password) VALUES (:client_name, :client_username, :client_email, :client_phone, :client_address, :client_password)";

$stmt = $conn->prepare($query);
$stmt->bindParam(':client_name', $client_name);
$stmt->bindParam(':client_username', $client_username);
$stmt->bindParam(':client_email', $client_email);
$stmt->bindParam(':client_phone', $client_phone);
$stmt->bindParam(':client_address', $client_address);
$stmt->bindParam(':client_password', $client_password);

$success = $stmt->execute();

if (!$success) {
    die("Couldn't enter data: " . $stmt->errorInfo()[2]);
}

$conn = null;
?>

<html>

<head>
    <title>Admin Aanmaken | Autoverhuur </title>
    <link rel="shortcut icon" type="image/png" href="assets/img/P.png.png">
</head>

<link rel="stylesheet" type="text/css" href="assets/css/manager_registered_success.css">
<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
<script type="text/javascript" src="assets/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

<body>

    <!-- Back to top button -->
    <button onclick="topFunction()" id="myBtn" title="Go to top">
        <span class="glyphicon glyphicon-chevron-up"></span>
    </button>

    <!-- JavaScript for back to top button -->
    <script type="text/javascript">
        window.onscroll = function () {
            scrollFunction()
        };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("myBtn").style.display = "block";
            } else {
                document.getElementById("myBtn").style.display = "none";
            }
        }

        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
    </script>

    <!-- Navigation -->
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation" style="color: black">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse"
                    data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="index.php">
                    Autoverhuur </a>
            </div>

            <?php
            if (isset($_SESSION['login_client'])) {
                ?>
                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Welcome
                                <?php echo $_SESSION['login_client']; ?></a></li>
                        <li>
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown"
                                        role="button" aria-haspopup="true" aria-expanded="false"><span
                                            class="glyphicon glyphicon-user"></span> Control Panel <span
                                            class="caret"></span> </a>
                                    <ul class="dropdown-menu">
                                        <li> <a href="entercar.php">Auto toevoegen</a></li>
                                        <li> <a href="enterdriver.php"> Bestuurder toevoegen</a></li>
                                        <li> <a href="clientview.php">Bekijk</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Uitloggen</a></li>
                    </ul>
                </div>
            <?php
        } else if (isset($_SESSION['login_customer'])) {
            ?>
                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Welcome
                                <?php echo $_SESSION['login_customer']; ?></a></li>
                        <ul class="nav navbar-nav">
                            <li><a href="#" class="dropdown-toggle active
                            <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown"
                                        role="button" aria-haspopup="true" aria-expanded="false"> Garagge <span
                                            class="caret"></span> </a>
                                    <ul class="dropdown-menu">
                                        <li> <a href="prereturncar.php">Terugkeren</a></li>
                                        <li> <a href="mybookings.php"> Mijn reserveringen</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Uitloggen</a></li>
                    </ul>
                </div>

            <?php
        } else {
            ?>

                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="clientlogin.php">Admin</a></li>
                        <li><a href="customerlogin.php">Klant</a></li>
                    </ul>
                </div>
            <?php
        }
        ?>
    </div>
</nav>

<div class="container">
    <div class="jumbotron" style="text-align: center;">
        <h2> <?php echo "Welcome $client_name!" ?> </h2>
        <h1>Account aangemaakt.</h1>
        <p>Om in te loggen druk <a href="clientlogin.php">Hier</a></p>
    </div>
</div>

</body>
<footer class="site-footer">
    <div class="container">
        <hr>
        <div class="row">
            <div class="col-sm-6">
                <h5> <?php echo date("Y"); ?> Auto verhuur</h5>
            </div>
        </div>
    </div>
</footer>

</html>
