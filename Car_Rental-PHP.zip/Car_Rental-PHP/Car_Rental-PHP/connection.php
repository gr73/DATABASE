<?php

class Database {
    public $conn;
    public $connected = false;
    private $host = 'localhost:3307';
    private $dbname = 'carrentalp';
    private $username = 'root';
    private $password = '';
    

    public function connect() {
        try {
            $this->conn = new PDO("mysql:host=$this->host;dbname=$this->dbname", $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->connected = true;
        } catch (PDOException $e) {
            // Log the error or handle it in a way that suits your application
            // For example, you can throw a custom exception
            throw new Exception("Connection failed: " . $e->getMessage());
        }
    }
    

    public function query($sql) {
        try {
            return $this->conn->query($sql);
        } catch (PDOException $e) {
            die("Query failed: " . $e->getMessage());
        }
    }

    public function prepare($sql) {
        try {
            return $this->conn->prepare($sql);
        } catch (PDOException $e) {
            die("Prepare failed: " . $e->getMessage());
        }
    }

    public function closeConnection() {
        $this->conn = null;
    }

    public function getConnectionError() {
        return $this->conn->errorInfo();
    }

    public function getPDO() {
        return $this->conn;
    }
}

$database = new Database();
$database->connect();
