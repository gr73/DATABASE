<!DOCTYPE html>
<html>

<head>
    <title>Customer Signup | Car Rentals</title>
    <link rel="shortcut icon" type="image/png" href="assets/img/P.png.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/customerlogin.css">
    <link rel="stylesheet" href="assets/w3css/w3.css">
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation" style="color: black">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="index.php">Auto verhuur</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->

            <?php
            session_start();
            if (isset($_SESSION['login_client'])) {
            ?>
                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <a href="#"><span class="glyphicon glyphicon-user"></span> Welkom <?php echo $_SESSION['login_client']; ?></a>
                        </li>
                        <li>
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span> Control Panel <span class="caret"></span> </a>
                                    <ul class="dropdown-menu">
                                        <li> <a href="entercar.php">Add Car</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Uitloggen</a>
                        </li>
                    </ul>
                </div>

            <?php
            } elseif (isset($_SESSION['login_customer'])) {
            ?>
                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <a href="#"><span class="glyphicon glyphicon-user"></span> Welkom<?php echo $_SESSION['login_customer']; ?></a>
                        </li>
                        <li>
                            <a href="#">Geschiedenis</a>
                        </li>
                        <li>
                            <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Uitloggen</a>
                        </li>
                    </ul>
                </div>

                <?php
} else {
?>
    <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
        <ul class="nav navbar-nav">
            <li>
                <a href="index.php">Home</a>
            </li>
            <li>
                <a href="clientlogin.php">Admin</a>
            </li>
            <li>
                <a href="customerlogin.php">Klant</a>
            </li>
        </ul>
    </div>
<?php
}

require 'connection.php';

try {
    $conn = new PDO("mysql:host=localhost:3307;dbname=carrentalp", 'root', '');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

function GetImageExtension($imagetype)
{
    if (empty($imagetype)) return false;

    switch ($imagetype) {
        case 'assets/img/cars/bmp':
            return '.bmp';
        case 'assets/img/cars/gif':
            return '.gif';
        case 'assets/img/cars/jpeg':
            return '.jpg';
        case 'assets/img/cars/png':
            return '.png';
        default:
            return false;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $car_name = isset($_POST['car_name']) ? $_POST['car_name'] : '';
    $car_nameplate = isset($_POST['car_nameplate']) ? $_POST['car_nameplate'] : '';
    $ac_price = isset($_POST['ac_price']) ? $_POST['ac_price'] : '';
    $non_ac_price = isset($_POST['non_ac_price']) ? $_POST['non_ac_price'] : '';
    $ac_price_per_day = isset($_POST['ac_price_per_day']) ? $_POST['ac_price_per_day'] : '';
    $non_ac_price_per_day = isset($_POST['non_ac_price_per_day']) ? $_POST['non_ac_price_per_day'] : '';

    if (!empty($car_name) && !empty($car_nameplate) && !empty($ac_price) && !empty($non_ac_price) && !empty($ac_price_per_day) && !empty($non_ac_price_per_day)) {

        // Check if the car with the given nameplate already exists
        $checkQuery = "SELECT * FROM cars WHERE car_nameplate = :car_nameplate";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bindParam(':car_nameplate', $car_nameplate);
        $checkStmt->execute();

        if ($checkStmt->rowCount() > 0) {
            echo "Car with the same vehicle number already exists!";
        } else {
            // Proceed with the insertion
            $car_availability = "yes"; // You can change this to the default value you want

            $query = "INSERT INTO cars(car_name,car_nameplate,ac_price,non_ac_price,ac_price_per_day,non_ac_price_per_day,car_availability) 
                    VALUES(:car_name, :car_nameplate, :ac_price, :non_ac_price, :ac_price_per_day, :non_ac_price_per_day, :car_availability)";

            $stmt = $conn->prepare($query);
            $stmt->bindParam(':car_name', $car_name);
            $stmt->bindParam(':car_nameplate', $car_nameplate);
            $stmt->bindParam(':ac_price', $ac_price);
            $stmt->bindParam(':non_ac_price', $non_ac_price);
            $stmt->bindParam(':ac_price_per_day', $ac_price_per_day);
            $stmt->bindParam(':non_ac_price_per_day', $non_ac_price_per_day);
            $stmt->bindParam(':car_availability', $car_availability);

            try {
                $stmt->execute();
                $car_id = $conn->lastInsertId();

                if (!empty($_FILES["uploadedimage"]["name"])) {
                    $file_name = $_FILES["uploadedimage"]["name"];
                    $temp_name = $_FILES["uploadedimage"]["tmp_name"];
                    $imgtype = $_FILES["uploadedimage"]["type"];
                    $ext = GetImageExtension($imgtype);
                    $imagename = $_FILES["uploadedimage"]["name"];
                    $target_path = "assets/img/cars/" . $imagename;

                    if (move_uploaded_file($temp_name, $target_path)) {
                        $query = "UPDATE cars SET car_img = :car_img WHERE car_id = :car_id";
                        $stmt = $conn->prepare($query);
                        $stmt->bindParam(':car_img', $target_path);
                        $stmt->bindParam(':car_id', $car_id);
                        $stmt->execute();
                    }
                }

                $query2 = "INSERT INTO clientcars(car_id, client_username) VALUES(:car_id, :client_username)";
                $stmt2 = $conn->prepare($query2);
                $stmt2->bindParam(':car_id', $car_id);
                $stmt2->bindParam(':client_username', $_SESSION['login_client']);
                $stmt2->execute();

                echo "Car successfully added.";
            } catch (PDOException $e) {
                echo "Error: " . $e->getMessage();
            }
        }
    } else {
        echo "Please fill in all the required fields.";
    }
}

?>

    </body>

    <footer class="site-footer">
        <div class="container">
            <hr>
            <div class="row">
                <div class="col-sm-6">
                    <h5> <?php echo date("Y"); ?> Auto verhuur</h5>
                </div>
            </div>
        </div>
    </footer>

</html>
